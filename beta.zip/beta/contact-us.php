<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Contact Us || OurStore</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800i" rel="stylesheet">

        <!-- favicon icon -->
        <link rel="shortcut icon" type="images/png" href="images/favicon.ico">

		<!-- all css here -->

		<link rel="stylesheet" href="style.css">
		<!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!-- Add your site or application content here -->
        <!--Start-Preloader-area-->
        <div class="preloader">
            <div class="loading-center">
                <div class="loading-center-absolute">
                    <div class="object object_one"></div>
                    <div class="object object_two"></div>
                    <div class="object object_three"></div>
                </div>
            </div>
        </div>
        <!--end-Preloader-area-->
        <!--header-area-start-->
        <!--Start-main-wrapper-->
        <div class="blog-page contact-page">
            <!--Start-Header-area-->
            <?php include("header.php");?>
            <!--End-Header-area-->
            <!--start-single-heading-banner-->
            <div class="single-banner-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                            <div class="single-ban-top-content">
                                <p>Contact Us</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end-single-heading-banner-->
            <!--start-single-heading-->
            <div class="signle-heading">
                <div class="container">
                    <div class="row">
                        <!--start-shop-head -->
                        <div class="col-lg-12">
                            <div class="shop-head-menu">
                                <ul>
                                    <li><i class="fa fa-home"></i><a class="shop-home" href="index.php"><span>Home</span></a><span><i class="fa fa-angle-right"></i></span></li>
                                    <li class="shop-pro">Contact Us</li>
                                </ul>
                            </div>
                        </div>
                        <!--end-shop-head-->
                    </div>
                </div>
            </div>
            <!--end-single-heading-->
            <!--contact-map-area-start-->
            <div class="map-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="map-area">
                                <div id="googleMap" style="width:100%;height:410px;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end-contact-map-area-->
            <!--stay_in_touch_area_start-->
            <div class="stay-touch-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                            <div class="touch-text">
                                <h3>Stay in touch</h3>
                            </div>
                            <div class="smal-text">
                                <p>This time there's no stopping us!" Makin' your way in the world today takes everything you've got. Takin' a break from all your worries sure would help a lot.</p>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="touch-form">
                                                <form action="mail.php" method="post">
                                                    <span class="name">Your Name (required)</span><br>
                                                    <input type="text" name="text"><br>
                                                    <span class="name">Your Email (required)</span><br>
                                                    <input type="tel" name="tel"><br>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <div class="touch-form">
                                                <form action="mail.php" method="post">
                                                   <span class="name">Your Phone (required)</span><br>
                                                    <input type="email" name="email"><br>
                                                   <span class="name">Subject</span><br>
                                                    <input type="text" name="text"><br>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="touch-textarea">
                                                <form action="mail.php" method="post">
                                                   <span class="name">Your Message</span><br>
                                                    <textarea name="textarea" id="textarea" cols="89" rows="5"></textarea><br>
                                                </form>
                                                <div class="continue-butt">
                                                    <form action="mail.php" method="post">
                                                        <input class="hvr-underline-from-left" type="submit" value="Send Message">
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="address-area">
                                <div class="single-address">
                                    <p><i class="fa fa-map-marker"></i> <strong class="stro">Address :</strong><br> <span class="add-tex"> 8901 Marmora Road, Glasgow <br> D05 90GR.</span></p>
                                </div>
                                <div class="single-email">
                                    <p><i class="fa fa-envelope-o"></i><strong class="emai-stro">Email :</strong><br> <span class="email-tex"> Contact@Mt-Shop.com <br>Info@Mt-Shop.com</span></p>
                                </div>
                                <div class="customar-supp">
                                    <p><i class="fa fa-phone"></i> <strong class="cus-stro">customer support :</strong><br> <span class="cus-tex"> +03 634 96 78 <br>+05 264 56 38.</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--stay_in_touch_area_End-->
            <!--Start-footer-wrap-->
            <?php include("footer.php");?>
            <!--End-footer-wrap-->

        </div>
        <!--End-main-wrapper-->

		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
		<!-- meanmenu.js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- nivo.slider.js -->
        <script src="lib/js/jquery.nivo.slider.js" type="text/javascript"></script>
        <script src="lib/home.js" type="text/javascript"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
		<!-- scrollUp.min.js -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- jquery.parallax.js -->
        <script src="js/jquery.parallax.js"></script>
		<!-- sticky.js -->
        <script src="js/jquery.sticky.js"></script>
		<!-- jquery.simpleGallery.min.js -->
        <script src="js/jquery.simpleGallery.min.js"></script>
        <script src="js/jquery.simpleLens.min.js"></script>
        <!-- countdown.min.js -->
        <script src="js/jquery.countdown.min.js"></script>
        <!-- isotope.pkgd.min -->
        <script src="js/isotope.pkgd.min.js"></script>
		<!-- wow js -->
        <script src="js/wow.min.js"></script>
        <!-- Google Map js -->
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC9PVYKr0fwtx4R9e7PTSj8qL1hhMU7My0"></script>
		<script>
			function initialize() {
			  var mapOptions = {
				zoom: 15,
				scrollwheel: false,
				center: new google.maps.LatLng(55.86424, -4.25181)
			  };

			  var map = new google.maps.Map(document.getElementById('googleMap'),
				  mapOptions);

			  var marker = new google.maps.Marker({
				position: map.getCenter(),
				animation:google.maps.Animation.BOUNCE,
				icon: 'images/icon/map-marker.png',
				map: map
			  });
			}
			google.maps.event.addDomListener(window, 'load', initialize);
		</script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
    </body>
</html>
