<?php

 $con = mysqli_connect("localhost", "d2lwhlc5s5dc", "e00gO%N(J/=<", "otlobOnline");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
